import AxeBuilder from "@axe-core/playwright";
import { expect, type Page } from "@playwright/test";
import { DEMO_PASSWORD } from "../src/api/auth";
import { content } from "../src/content";
import { addDaysISO, todayISO } from "../src/lib/dates";
import { seedBookings } from "../src/mocks/bookings";
import { seedCustomers } from "../src/mocks/customers";

/** A 1×1 PNG, standing in for a phone photo of an ID. */
const SAMPLE_PHOTO_BASE64 =
  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==";
const samplePhoto = { fileName: "photo.png", dataUrl: `data:image/png;base64,${SAMPLE_PHOTO_BASE64}` };

/** The three booking documents, already uploaded, for tests that start mid-flow. */
export const SAMPLE_DOCUMENTS = { validId: samplePhoto, proofOfBilling: samplePhoto, driversLicense: samplePhoto };

/** Uploads a photo for each document on the "Your details" step. */
export async function uploadDocuments(page: Page): Promise<void> {
  for (const kind of ["validId", "proofOfBilling", "driversLicense"] as const) {
    const label = content.booking.documents.kinds[kind].label;
    await page.getByLabel(label, { exact: true }).setInputFiles({
      name: `${kind}.png`,
      mimeType: "image/png",
      buffer: Buffer.from(SAMPLE_PHOTO_BASE64, "base64"),
    });
    await expect(page.getByText(`${kind}.png`)).toBeVisible();
  }
}

/**
 * Adds a booking whose documents staff have just approved, so it is waiting for payment, and
 * returns what the customer needs to open the pay page.
 */
export async function addApprovedBooking(
  page: Page,
  { customerId }: { customerId?: string } = {},
): Promise<{ reference: string; email: string; total: number }> {
  const confirmed = seedBookings.find((booking) => booking.status === "confirmed")!;
  const source = { ...confirmed, customerId: customerId ?? confirmed.customerId };
  const email = seedCustomers.find((customer) => customer.id === source.customerId)!.email;
  const booking = {
    ...source,
    id: "bkg-e2e-approved",
    reference: "RC-PAYM3E",
    status: "approved",
    documentsStatus: "verified",
    approvedAt: new Date().toISOString(),
    paymentId: null,
  };
  await visit(page, "/");
  await page.evaluate((row) => {
    const key = Object.keys(localStorage).find((name) => name.startsWith("car-rental-mock-db"))!;
    const db = JSON.parse(localStorage.getItem(key)!);
    db.bookings.unshift(row);
    localStorage.setItem(key, JSON.stringify(db));
  }, booking);
  return { reference: booking.reference, email, total: booking.total };
}

/** Opens the emailed pay (or new-photos) link and gets past the email check. */
export async function openOwnBooking(page: Page, path: string, email: string): Promise<void> {
  await visit(page, path);
  await page.getByLabel(content.booking.access.email).fill(email);
  await page.getByRole("button", { name: content.booking.access.continue }).click();
}

/** An ISO date N days from today in Manila time, the same clock the site uses. */
export const dateFromToday = (days: number): string => addDaysISO(todayISO(), days);

/** Opens a page and waits until the browser has finished loading its scripts and data. */
export async function visit(page: Page, path: string): Promise<void> {
  await page.goto(path);
  await page.waitForLoadState("networkidle");
  // On the public site a full-screen "Powered by" screen covers a fresh load for a moment. Wait for it to
  // leave, as a visitor would, so clicks and accessibility scans see the real page.
  await expect(page.locator("[data-splash]")).toHaveCount(0, { timeout: 15_000 });
}

/** The demo staff login. Everyone who signs in is an admin, so there is only one to pick. */
export const demoAccount = () => content.admin.login.demo.accounts[0];

/** Signs in through the real login form. */
export async function loginAs(page: Page, from = "/admin/login"): Promise<void> {
  await visit(page, from);
  await page.getByLabel(content.admin.login.email).fill(demoAccount().email);
  await page.getByLabel(content.admin.login.password).fill(DEMO_PASSWORD);
  await page.getByRole("button", { name: content.admin.login.submit }).click();
  await page.waitForURL((url) => url.pathname.startsWith("/admin") && url.pathname !== "/admin/login");
  await page.waitForLoadState("networkidle");
}

/**
 * Error and warning messages inside the page's main content. Next.js also keeps its own
 * hidden "alert" for announcing page changes, so plain getByRole("alert") counts one too many.
 */
export const pageAlerts = (page: Page) => page.getByRole("main").getByRole("alert");

/**
 * Waits for any running CSS transition/animation to settle (e.g. a dialog's entrance fade),
 * so a scan right after `toBeVisible()` doesn't sample a mid-animation frame and read a
 * transiently-lower contrast than the finished state has. Skips animations that loop forever
 * (the skeleton shimmer, a loading button's spinner) so this never hangs; 1s safety cap besides.
 */
async function waitForAnimationsToSettle(page: Page): Promise<void> {
  await page.evaluate(() =>
    Promise.race([
      Promise.all(
        document
          .getAnimations()
          .filter((a) => a.effect?.getTiming().iterations !== Infinity)
          .map((a) => a.finished.catch(() => {})),
      ),
      new Promise((resolve) => setTimeout(resolve, 1000)),
    ]),
  );
}

/**
 * Runs the axe accessibility checker on the current page and fails with a readable list
 * of problems. Covers WCAG 2.0/2.1/2.2 A and AA plus axe's best-practice rules.
 * `skipRules` switches off named rules, for the rare screen where one cannot apply (say why at the call).
 * `scope` (a CSS selector) checks just that part of the page.
 */
export async function expectNoA11yViolations(page: Page, skipRules: string[] = [], scope?: string): Promise<void> {
  await waitForAnimationsToSettle(page);
  let axe = new AxeBuilder({ page })
    .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa", "best-practice"])
    .disableRules(skipRules);
  if (scope) axe = axe.include(scope);
  const results = await axe.analyze();

  const problems = results.violations.map((violation) => {
    const where = violation.nodes
      .slice(0, 3)
      .map((node) => `    ${node.target.join(" ")}`)
      .join("\n");
    return `${violation.id} [${violation.impact}]: ${violation.help}\n${where}`;
  });

  expect(problems, `Accessibility problems on ${new URL(page.url()).pathname}`).toEqual([]);
}
