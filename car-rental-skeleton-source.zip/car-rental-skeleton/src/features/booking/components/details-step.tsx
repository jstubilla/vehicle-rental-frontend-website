"use client";

import Link from "next/link";
import { Controller } from "react-hook-form";
import { Button, Card, CardContent, FormField, Input, Textarea } from "@/components/ui";
import { content } from "@/content";
import { PrivacyNote } from "@/features/shared/privacy-note";
import { DOCUMENT_KINDS } from "@/lib/constants";
import { useBookingQuote } from "../hooks/use-booking-quote";
import { useDetailsStep } from "../hooks/use-details-step";
import { useStepGuard } from "../hooks/use-step-guard";
import type { FlowState } from "../flow-store";
import type { DetailsStepValues } from "../schemas";
import { previousStepPath } from "../steps";
import { summaryFromFlow } from "../summary";
import { BookingSummary } from "./booking-summary";
import { DocumentUpload } from "./document-upload";
import { StepActions, StepHeading, StepSkeleton } from "./step-parts";

const t = content.booking.details;

export function DetailsStep() {
  const { ready, state } = useStepGuard("details");
  if (!ready) return <StepSkeleton />;

  const initial: DetailsStepValues = {
    ...(state.customer ?? { name: "", email: "", phone: "", licenseNumber: "", notes: "" }),
    documents: state.documents ?? { validId: null, proofOfBilling: null, driversLicense: null },
  };
  return <DetailsForm initial={initial} state={state} />;
}

function DetailsForm({ initial, state }: { initial: DetailsStepValues; state: FlowState }) {
  const { vehicle, quote } = useBookingQuote();
  const { form, onSubmit, savedDetails, answerSavedDetails } = useDetailsStep(initial, state.customer !== null);
  const { register, control, formState } = form;
  const { errors } = formState;

  return (
    <div className="grid gap-8 lg:grid-cols-3">
      <form onSubmit={onSubmit} noValidate className="flex min-w-0 flex-col gap-6 lg:col-span-2">
        <StepHeading title={t.title} description={t.description} />

        {savedDetails === "offer" && (
          <Card variant="muted" as="section" aria-labelledby="saved-details-heading">
            <CardContent className="flex flex-col gap-3 pt-4 md:pt-6">
              <h2 id="saved-details-heading" className="text-lg">
                {t.savedDetails.title}
              </h2>
              <p className="text-muted">{t.savedDetails.description}</p>
              <div className="flex flex-wrap gap-2">
                <Button type="button" variant="secondary" onClick={() => answerSavedDetails(true)}>
                  {t.savedDetails.yes}
                </Button>
                <Button type="button" variant="outline" onClick={() => answerSavedDetails(false)}>
                  {t.savedDetails.no}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
        {savedDetails === "login" && (
          <p className="text-sm text-muted">
            {t.loginPrompt.text} <Link href="/login?next=/book/details" className="underline underline-offset-4">{t.loginPrompt.link}</Link>
          </p>
        )}

        <FormField label={t.name} required error={errors.name?.message}>
          <Input {...register("name")} autoComplete="name" />
        </FormField>

        <div className="grid gap-4 sm:grid-cols-2">
          <FormField label={t.email} required error={errors.email?.message}>
            <Input {...register("email")} type="email" autoComplete="email" />
          </FormField>
          <FormField label={t.phone} required hint={t.phoneHint} error={errors.phone?.message}>
            <Input {...register("phone")} type="tel" autoComplete="tel" />
          </FormField>
        </div>

        <FormField label={t.license} required hint={t.licenseHint} error={errors.licenseNumber?.message}>
          <Input {...register("licenseNumber")} autoComplete="off" />
        </FormField>

        <section aria-labelledby="documents-heading" className="flex flex-col gap-3">
          <div className="flex flex-col gap-1">
            <h2 id="documents-heading" className="text-lg">
              {content.booking.documents.title}
            </h2>
            <p className="text-sm text-muted">{content.booking.documents.description}</p>
          </div>
          {DOCUMENT_KINDS.map((kind) => (
            <Controller
              key={kind}
              control={control}
              name={`documents.${kind}`}
              render={({ field, fieldState }) => (
                <DocumentUpload
                  label={content.booking.documents.kinds[kind].label}
                  hint={content.booking.documents.kinds[kind].hint}
                  value={field.value}
                  onChange={field.onChange}
                  error={fieldState.error?.message}
                />
              )}
            />
          ))}
        </section>

        <FormField label={t.notes}>
          <Textarea {...register("notes")} />
        </FormField>

        <PrivacyNote />

        <StepActions backHref={previousStepPath("details")}>
          <Button type="submit" size="lg" variant="accent" arrow>
            {content.booking.common.continue}
          </Button>
        </StepActions>
      </form>

      <aside className="order-first min-w-0 lg:order-none lg:col-span-1">
        <BookingSummary
          data={summaryFromFlow({ state, vehicle, quote })}
          collapsible
          className="lg:sticky lg:top-24"
        />
      </aside>
    </div>
  );
}
