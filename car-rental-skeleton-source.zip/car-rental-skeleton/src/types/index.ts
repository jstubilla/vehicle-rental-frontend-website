import type { ImageAsset } from "@/assets/config";
import type {
  ActivityType,
  BookingStatus,
  ContactType,
  DocumentKind,
  DocumentStatus,
  LeadSource,
  LeadStage,
  OnlinePaymentMethod,
  PaymentMethod,
  PaymentStatus,
  TaskStatus,
  VehicleCategory,
  VehicleStatus,
} from "@/lib/constants";

/**
 * Data models. These mirror what a real backend would return, so swapping the
 * mock layer for an API should not require changing them. Dates are ISO strings.
 * Money is in PHP.
 */

/**
 * A type of vehicle (not one particular car): what it is, an example of it, how many it seats at most,
 * and what it costs. Bookings are for a type, and staff hand over a matching vehicle.
 */
export interface Vehicle {
  id: string;
  slug: string;
  /** The type's display name, e.g. "Sedan". */
  name: string;
  category: VehicleCategory;
  /** What a customer can expect, e.g. "Toyota Vios or similar". */
  examples: string;
  /** The most people it seats. Cars and vans always have this; motorcycles don't carry a seat count. */
  seats?: number;
  /** Flat daily rate in PHP. Staff with the pricing permission can change it from the Pricing screen; bookings keep the rate they were made at. */
  pricePerDay: number;
  status: VehicleStatus;
  featured: boolean;
  images: ImageAsset[];
}

/** An extra phone number or email for a customer or lead (the main ones are on the record itself). */
export interface ContactDetail {
  id: string;
  type: ContactType;
  value: string;
  /** e.g. "Office", "Assistant", "Personal". */
  label: string;
}

export interface Lead {
  id: string;
  name: string;
  email: string;
  phone: string;
  source: LeadSource;
  stage: LeadStage;
  /** Vehicle id the person asked about, if any. */
  vehicleInterest: string | null;
  message: string;
  additionalContacts: ContactDetail[];
  assigneeId: string | null;
  customerId: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface Activity {
  id: string;
  type: ActivityType;
  body: string;
  entityType: "lead" | "customer";
  entityId: string;
  /** null = created by the system (e.g. a website form). */
  authorId: string | null;
  createdAt: string;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  licenseNumber: string | null;
  notes: string;
  additionalContacts: ContactDetail[];
  createdAt: string;
}

/** A photo the customer sent (e.g. their valid ID), as a compressed JPEG data URL. */
export interface UploadedDocument {
  fileName: string;
  dataUrl: string;
}

export type BookingDocuments = Record<DocumentKind, UploadedDocument>;

/**
 * A booking keeps its own copy of the price it was made at (dailyRate, driverRate and the
 * totals). If the owner changes a vehicle's rate later, existing bookings
 * keep their original price and only new bookings use the new rate.
 */
export interface Booking {
  id: string;
  /** Customer-facing code, e.g. "RC-K7M2QA". */
  reference: string;
  customerId: string;
  vehicleId: string;
  /** Wherever the visitor typed or pasted (an address, or a Google Maps link) — there is no preset list. */
  pickupLocation: string;
  /** Same idea, for the return leg. */
  returnLocation: string;
  pickupDate: string;
  pickupTime: string;
  returnDate: string;
  returnTime: string;
  days: number;
  dailyRate: number;
  vehicleTotal: number;
  /** "With a driver" (true) or "Vehicle only" (false). */
  withDriver: boolean;
  /** The driver's daily rate at booking time (0 for "Vehicle only"), kept like dailyRate. */
  driverRate: number;
  driverTotal: number;
  total: number;
  status: BookingStatus;
  /**
   * The customer's valid ID, proof of billing and driver's license. Staff check them before
   * confirming the booking. Bookings made before documents were asked for have none.
   */
  documents?: BookingDocuments | null;
  documentsStatus?: DocumentStatus | null;
  /** Why staff rejected the documents, shown to the customer so they can send new photos. */
  rejectionReason?: string | null;
  /** When staff approved the documents. The customer must pay within PAYMENT_DEADLINE_HOURS of this. */
  approvedAt?: string | null;
  /** Set when the customer cancelled the booking themselves (only possible before paying). */
  cancellation?: { by: "customer"; reason: string; at: string } | null;
  paymentId: string | null;
  notes: string;
  createdAt: string;
  updatedAt: string;
}

/**
 * A payment record. It only ever holds a method, an amount and the payment
 * provider's reference. Card numbers are never collected or stored here.
 */
export interface Payment {
  id: string;
  bookingId: string;
  method: PaymentMethod;
  amount: number;
  status: PaymentStatus;
  /** Reference from the payment provider (mock value for now). */
  providerRef: string | null;
  /**
   * "Pay at pick-up" only: the down payment charged online when booking. `amount` stays the
   * full total, and `status` stays "pending" until staff record the balance at pick-up.
   */
  downPayment?: { method: OnlinePaymentMethod; amount: number } | null;
  createdAt: string;
}

/** A page of results, the same shape a real paginated API would return. */
export interface Paginated<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
  pageCount: number;
}

/** A staff account. Every staff account is an admin and may do everything. */
export interface User {
  id: string;
  name: string;
  email: string;
  active: boolean;
  createdAt: string;
}

/** A to-do or follow-up, optionally linked to a lead or a customer. */
export interface Task {
  id: string;
  title: string;
  notes: string;
  /** ISO date ("2026-10-03"). */
  dueDate: string;
  assigneeId: string | null;
  status: TaskStatus;
  linkedType: "lead" | "customer" | null;
  linkedId: string | null;
  createdAt: string;
  completedAt: string | null;
}

/** A customer's review of the overall service (not of one car or one booking). Private until staff choose to show it. */
export interface Review {
  id: string;
  name: string;
  /** 1 to 5 stars. */
  rating: number;
  comment: string;
  /** The booking reference the customer gave. Only staff can see it. */
  bookingReference: string;
  /** Whether staff chose to show it on the public website. */
  published: boolean;
  createdAt: string;
}

/** What the public website is allowed to know about a shown review. */
export type PublicReview = Pick<Review, "id" | "name" | "rating" | "comment" | "createdAt">;

/** A website customer's login (not a staff user, and separate from the CRM customer list). */
export interface Account {
  id: string;
  name: string;
  email: string;
  /** MOCK ONLY. A real back end never stores a password, only a hash of it. */
  password: string;
  /** Saved from the last booking, so the next one can be filled in. Empty until then. */
  phone: string;
  licenseNumber: string;
  createdAt: string;
}

/** What the browser is allowed to see of an account (never the password). */
export type AccountProfile = Omit<Account, "password">;
