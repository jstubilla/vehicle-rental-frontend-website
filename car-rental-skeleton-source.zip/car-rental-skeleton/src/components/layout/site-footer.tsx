import { content } from "@/content";
import { Footer, Logo, SocialLinks } from "@/components/ui";

/** Public footer: wires site content into the Footer from the UI kit. */
export function SiteFooter() {
  return (
    <Footer
      brand={<Logo />}
      description={content.site.description}
      phone={{ label: content.footer.phoneLabel, number: content.site.contactPhone }}
      columns={content.footer.columns}
      socials={<SocialLinks links={content.socials} />}
      socialsTitle={content.footer.socialsTitle}
      legal={content.footer.legal}
      legalLinks={[content.footer.staffLogin]}
      credit={content.footer.credit}
    />
  );
}
